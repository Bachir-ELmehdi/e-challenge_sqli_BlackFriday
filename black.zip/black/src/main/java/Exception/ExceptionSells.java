package Exception;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> black
 * Package =====> Exception
 * Date    =====> 21 nov. 2019 
 */
public class ExceptionSells extends RuntimeException {

	/**
	 * 
	 */

}
