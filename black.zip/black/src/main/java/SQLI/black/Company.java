package SQLI.black;

import Exception.ExceptionSells;


/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> black
 * Package =====> SQLI.black
 * Date    =====> 20 nov. 2019 
 */

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> blackfriday
 * Package =====> entitie
 * Date    =====> 20 nov. 2019 
 */
public class Company {
	
	private Stock stock =new Stock();
	private int totaleCapsule =0 ;
	private int totalemachine ;
	private int totale ;
	private boolean blackfriday;

	
/**
 * 
 */
public Company() {
	// TODO Auto-generated constructor stub
	totaleCapsule =0;
	totale = 0;
	totalemachine = 0;
}
	
	public  void stock(int prix, String nom, int quantite) {
		if(nom.equals("capsule")) 
		{
			stock.initialiseStockCapsule(quantite, prix);
		}
		 if (nom.equals("machine"))
		{stock.initialiseStockmachine(quantite, prix);}
	}
	
	
	public float sells(String nom) {
		float resulta = 0; 
		if(stock.getQuantiteCapsule() + stock.getQuantiteMachine()==0)
		{
			throw new ExceptionSells();
		}
		/////-------la vente  du  Capsule----//////////
		if(nom.equals("capsule"))
		{    if(blackfriday) {
				totaleCapsule  = (int) (totaleCapsule+ (stock.getPrixCapsuleNet()*stock.getQuantiteCapsule()));
				totaleCapsule+= totaleCapsule* 0.1;
			    stock.setQuantiteCapsule(stock.getQuantiteCapsule());
		     	resulta = totaleCapsule;
		     	
		    } else {
		    	if(stock.getPrixCapsuleNet() == 5) {
					totaleCapsule = (int) (stock.getQuantiteCapsule() * stock.getPrixCapsuleNet());
					stock.setQuantiteCapsule(stock.getQuantiteCapsule());
					totaleCapsule+= totaleCapsule* 0.2;

					resulta = totaleCapsule;
			    	} else {
				    	totaleCapsule=0;
						totaleCapsule  += (int) (stock.getPrixCapsuleNet()*1) ;
						totaleCapsule+= totaleCapsule* 0.2;
						setTotale(totaleCapsule);
					    stock.setQuantiteCapsule(1);		
						resulta = totaleCapsule;}
						}
		 
		}
		/////-------la vente  du  Machine----//////////

		else if(nom.equals("machine"))
			{    if(blackfriday) {
						totalemachine = (int) (stock.getPrixMachineNet()*(stock.getQuantiteMachine()));
						totalemachine+= totalemachine* 0.1;  
					    stock.setQuantiteMachine(stock.getQuantiteMachine())	;
						resulta = totalemachine;
		                                                         	}
		     	  else {
			
						if(stock.getQuantiteMachine() >=100) {
							totalemachine = (int) (stock.getQuantiteMachine()*stock.getPrixMachineNet());
							totalemachine+= totalemachine* 0.2;  
							resulta = totalemachine;
						    stock.setQuantiteMachine(stock.getQuantiteMachine())	;
					             }
						else {
							totalemachine = (int) (stock.getPrixMachineNet()*(stock.getQuantiteMachine()/2));
							totalemachine+= totalemachine* 0.2;  
						    stock.setQuantiteMachine(5)	;
							resulta = totalemachine;}
		              }
			}
		return  resulta;
	}
	
	//---------Met BlackFriday  a true ----------//
	public Company blackFriday() {
		blackfriday = true;
		return this;
	}
	
	//----totale Assets-------///
	public int  totalAssets() {
		if(stock.getQuantiteCapsule() >0)
			totaleCapsule = (int) (stock.getPrixCapsuleNet()*stock.getQuantiteCapsule());
		if( stock.getQuantiteMachine() >0)
			totalemachine += (int) stock.getPrixMachineNet()*stock.getQuantiteMachine();
		
		totale += totaleCapsule+totalemachine; 
		return totale;
	}
	
	/**
	 * @param totale the totale to set
	 */
	public void setTotale(int totale) {
		this.totale = totale;
	}



}
	