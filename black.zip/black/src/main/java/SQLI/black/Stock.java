package SQLI.black;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> black
 * Package =====> SQLI.black
 * Date    =====> 20 nov. 2019 
 */

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> blackfriday
 * Package =====> entitie
 * Date    =====> 20 nov. 2019 
 */
public class Stock {
	private int quantiteCapsule;
	private int  prixCapsuleNet;
	private int quantiteMachine;
	private int  prixMachineNet;
	
	/**
	 * 
	 */
	public Stock() {
		// TODO Auto-generated constructor stub
	
	}
	
	public void initialiseStockCapsule(int Qcapsule,int  pCapsule) {
		this.quantiteCapsule = Qcapsule;
		this.prixCapsuleNet = pCapsule;
	
	}
	
	public void initialiseStockmachine(int Qmachine,int  pmachine) {
		this.quantiteMachine = Qmachine;
		this.prixMachineNet = pmachine;
	}
	
	
	////les geters 
	/**
	 * @return the prixCapsuleNet
	 */
	public float getPrixCapsuleNet() {
		return prixCapsuleNet;
	}
	/**
	 * @return the prixMachineNet
	 */
	public float getPrixMachineNet() {
		return prixMachineNet;
	}
	/**
	 * @return the quantiteCapsule
	 */
	public int getQuantiteCapsule() {
		return quantiteCapsule;
	}
	/**
	 * @return the quantiteMachine
	 */
	public int getQuantiteMachine() {
		return quantiteMachine;
	}
	
	/**
	 * @param prixCapsuleNet the prixCapsuleNet to set
	 */
	public void setPrixCapsuleNet(int  prixCapsuleNet) {
		this.prixCapsuleNet = prixCapsuleNet;
	}
	/**
	 * @param prixMachineNet the prixMachineNet to set
	 */
	public void setPrixMachineNet(int  prixMachineNet) {
		this.prixMachineNet = prixMachineNet;
	}
	
	/**
	 * @param quantiteCapsule the quantiteCapsule to set
	 */
	public void setQuantiteCapsule(int quantiteCapsule) {
		this.quantiteCapsule -= quantiteCapsule;
	}
	/**
	 * @param quantiteMachine the quantiteMachine to set
	 */
	public void setQuantiteMachine(int quantiteMachine) {
		this.quantiteMachine -= quantiteMachine;
	}
	
	

}
